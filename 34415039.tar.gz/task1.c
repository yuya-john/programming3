#include <stdio.h>
int main(void)
{
puts ("学籍番号：34415039");
puts ("氏名：高森悠矢");
// 整数値15と37の加算結果を表示
return 0; }